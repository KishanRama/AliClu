#!/usr/bin/python
"""
Created on Sat Mar 17 00:06:10 2018

@author: kisha_000
"""

#from matplotlib import pyplot as plt
#matplotlib.use('Agg')

import matplotlib
matplotlib.use('agg',warn=False, force=True)
from matplotlib import pyplot as plt

print('hello')