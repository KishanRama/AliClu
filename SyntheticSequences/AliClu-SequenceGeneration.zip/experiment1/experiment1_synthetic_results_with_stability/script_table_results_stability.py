# -*- coding: utf-8 -*-
"""
Created on Sun May  6 16:22:33 2018

@author: kisha_000
"""

import pandas as pd

fname = 'experiment1_synthetic_nclusters_2_rates_[1000, 1]_ward_cluster_stability.txt'

with open(fname, "r") as ins:
    array = []
    for line in ins:
        line_aux = " ".join(line.split())
        if(line_aux):
            if(line_aux[0]=='1' or line_aux[0]=='2'): 
                words = line_aux.split()
                words[0] = str(round(float(words[0]),3))
                for i in range(1,len(words)):
                    word_back_slash = words[i].split('/')
                    words[i] = str(round(float(word_back_slash[0]),3)) + ' (' + str(round(float(word_back_slash[1]),3)) + ')'
                                       
                array.append(words)    
          

df = pd.DataFrame(array)
df.columns = ['Cluster','Length','J_median','D_median','A_median',
                                  'J_avg','D_avg','A_avg','J_std','D_std','A_std']
              
filename_csv = fname[:-4] + '.csv'              
df.to_csv(filename_csv)